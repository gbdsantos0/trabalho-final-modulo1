package com.dbc.pokesuits;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PokesuitsApplicationTests {

	@Test
	void contextLoads() {
	}

}
